import {DataTypes, Model } from 'sequelize';
import { sequelize } from '../../database/db';
import httpStatus from 'http-status';
import ApiError from '../../utils/ApiError';
import helpers from '../../utils/helpers';


class CompoundingPlan extends Model {}

export interface CompoundingPlanInterface<T> {
    id: T,
    uuid: T,
    plan: T,
    minAmt: T,
    duration: T,
    gurantee: T,
    dailyInterestRate: T,
}

CompoundingPlan.init({
    uuid: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4
    },
    plan: {
        type: DataTypes.STRING,
        defaultValue: "0"
    },
    minAmt: {
        type: DataTypes.STRING,
        defaultValue: "0"
    },
    maxAmt: {
        type: DataTypes.STRING,
        defaultValue: "0"
    },
    duration: {
        type: DataTypes.STRING,
        defaultValue: "0"
    },
    guarantee: {
        type: DataTypes.STRING,
        defaultValue: "0"
    },
    dailyInterestRate: {
        type: DataTypes.STRING,
        defaultValue: "0"
    }
  },
  {
      sequelize,
      modelName: 'CompoundingPlan',
      timestamps: true,
      updatedAt: 'updateTimestamp'
  })

export default CompoundingPlan;

