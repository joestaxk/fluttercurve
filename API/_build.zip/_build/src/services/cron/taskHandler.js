"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const init_1 = __importDefault(require("./init"));
const services_1 = __importDefault(require("./services"));
const newJob = new init_1.default();
console.log("---- reading TaskHandler --------");
var taskHandler = {};
// what are the task we want to hanlde.
/**
 * # Send bulk email @ night
 * # Go through DB in search of expired deposit and kick it off
 * # Increase Invesments when it's time.
 * # Send Email if needed. and more.
 */
taskHandler.ongoingServices = [];
taskHandler.depositCronUpdates = function () {
    console.log("---- reading depositCronUpdate --------");
    const task = newJob.add(services_1.default.depositService, "minutes", "depositservice", true);
    taskHandler.ongoingServices.push(task);
};
taskHandler.init = {
    depositCronUpdates: taskHandler.depositCronUpdates,
};
exports.default = taskHandler;
