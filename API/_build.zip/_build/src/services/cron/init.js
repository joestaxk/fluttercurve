"use strict";
var __classPrivateFieldGet = (this && this.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _Cron_instances, _Cron_schedules;
Object.defineProperty(exports, "__esModule", { value: true });
const cron = require('node-cron');
class Cron {
    constructor() {
        _Cron_instances.add(this);
        this.tasks = {};
    }
    add(task, type, id, remote) {
        if (!id)
            return;
        this.tasks[id] = __classPrivateFieldGet(this, _Cron_instances, "m", _Cron_schedules).call(this, task)[type](remote || true);
        return this.tasks[id];
    }
    stop(id) {
        this.tasks[id].start();
    }
    start(id) {
        this.tasks[id].start();
    }
    drop(id) {
        delete this.tasks[id];
    }
}
exports.default = Cron;
_Cron_instances = new WeakSet(), _Cron_schedules = function _Cron_schedules(task) {
    return {
        minutes: function (remote) {
            console.log(' 🔥🔥🔥 MINUTE CRON IN SERVICE 🔥🔥🔥`');
            return cron.schedule('* * * *  *', function () {
                task();
            }, {
                scheduled: remote
            });
        },
        daily: function (remote) {
            console.log(' 🔥🔥🔥 DAILY CRON IN SERVICE 🔥🔥🔥`');
            return cron.schedule('* * 23 * * *', function () {
                task();
            }, {
                scheduled: remote
            });
        },
        monthly: function (remote) {
            console.log(' 🔥🔥🔥 MONTHLY CRON IN SERVICE 🔥🔥🔥`');
            return cron.schedule('* * * 28 * *', function () {
                task();
            }, {
                scheduled: remote
            });
        }
    };
};
