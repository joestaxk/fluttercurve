

export default function Page(){
    return <>Manage Users</>
}