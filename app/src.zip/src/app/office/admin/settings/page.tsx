

export default function Page(){
    return <>Settings</>
}