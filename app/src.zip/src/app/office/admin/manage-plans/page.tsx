

export default function Page(){
    return <>Manage Plans</>
}