

export default function Page(){
    return <>Send Message</>
}